import 'dart:ui';

class ColorConstants {
  static const Color green = Color(0xff4fb65c);
  static const Color blue = Color(0xff0085fc);
}

// item_list_screen.dart

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:unstop/screens/edit/edit_screen.dart';

class ItemListScreen extends StatelessWidget {
  final _auth = FirebaseAuth.instance;
  final _firestore = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    final user = _auth.currentUser;

    return Scaffold(
      
      appBar: AppBar(
        backgroundColor: Colors.grey[850],
        title: const Text(
          'Item List',
          style: TextStyle(
             
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 24,
             
          ),
        ),
        leading: const BackButton(color: Colors.white),
        // centerTitle: false,
      ),
      backgroundColor: Colors.white,
      body: StreamBuilder<QuerySnapshot>(
        stream: _firestore.collection('users').doc(user?.uid).collection('items').snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final items = snapshot.data!.docs;

          if (items.isEmpty) {
            return const Center(
              child: Text(
                'No items saved yet',
                style: TextStyle(color: Colors.black, fontSize: 16,fontWeight: FontWeight.w600),
              ),
            );
          }

          return ListView.builder(
            itemCount: items.length,
            itemBuilder: (context, index) {
              final item = items[index].data() as Map<String, dynamic>;
              final docId = items[index].id;

              return Card(
                color: Colors.grey,
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                child: ListTile(
                  title: Text(
                    item['name'] ?? '',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                       
                      color: Colors.white,
                    ),
                  ),
                  // subtitle: Text(
                  //   item['location'] ?? '',
                  //   style: const TextStyle(color: Colors.white70, fontFamily: 'SpaceMono'),
                  // ),
                  // trailing: IconButton(
                  //   icon: const Icon(Icons.edit, color: Colors.white),
                  //   onPressed: () {
                      
                  //   },
                  // ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:unstop/bloc/auth_bloc.dart';
import 'package:unstop/bloc/auth_event.dart';
import 'package:unstop/screens/homescreen.dart';
import 'package:unstop/widgets/pop_up.dart';

// Future<void> handleStripePayment({
//   required BuildContext context,
//   required String firestoreField,
// }) async {
//   try {
//     final response = await fetchPaymentIntentClientSecret();
//     final clientSecret = response['clientSecret'];

//     await Stripe.instance.initPaymentSheet(
//       paymentSheetParameters: SetupPaymentSheetParameters(
//         paymentIntentClientSecret: clientSecret,
//         merchantDisplayName: 'UN-LOST',
//         style: ThemeMode.light,
//       ),
//     );

//     await Stripe.instance.presentPaymentSheet();

//     final user = FirebaseAuth.instance.currentUser;
//     if (user != null) {
//       await FirebaseFirestore.instance.collection('users').doc(user.uid).update({
//         firestoreField: true,
//       });

//       context.read<AuthBloc>().add(
//         LoggedIn(
//           user.uid,
//           user.email!,
//           itemSubscribed: firestoreField == 'itemSubscribed',
//           locationSubscribed: firestoreField == 'locationSubscribed',
//         ),
//       );
//     }

//     ScaffoldMessenger.of(context).showSnackBar(
//       const SnackBar(content: Text('Payment successful! ✅')),
//     );

//     Navigator.of(context).pushAndRemoveUntil(
//       MaterialPageRoute(builder: (_) => const HomeScreen()),
//       (route) => false,
//     );
//   } catch (e) {
//     debugPrint('❌ Stripe payment error: $e');
//     ScaffoldMessenger.of(context).showSnackBar(
//       const SnackBar(content: Text('Payment failed. Try again.')),
//     );
//   }
// }

Future<void> handleStripePayment({
  required BuildContext context,
  required String firestoreField, // 'itemSubscribed' or 'locationSubscribed'
}) async {
  try {
    final response = await fetchPaymentIntentClientSecret();
    final clientSecret = response['clientSecret'];

    await Stripe.instance.initPaymentSheet(
      paymentSheetParameters: SetupPaymentSheetParameters(
        paymentIntentClientSecret: clientSecret,
        merchantDisplayName: 'UN-LOST',
        style: ThemeMode.light,
      ),
    );

    await Stripe.instance.presentPaymentSheet();

    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final userRef = FirebaseFirestore.instance.collection('users').doc(user.uid);

    // 🔄 For 'itemSubscribed' → increment itemUpgrades & itemLimit
    if (firestoreField == 'itemSubscribed') {
      final doc = await userRef.get();
      final currentUpgrades = doc.data()?['itemUpgrades'] ?? 0;
      final newLimit = 25 * (currentUpgrades + 2);

      await userRef.update({
        'itemSubscribed': true,
        'itemUpgrades': currentUpgrades + 1,
        'itemLimit': newLimit,
      });

      context.read<AuthBloc>().add(
        LoggedIn(user.uid, user.email!, itemSubscribed: true),
      );
    }
    // 🔄 For 'locationSubscribed' → just toggle the flag
    else if (firestoreField == 'locationSubscribed') {
      await userRef.update({
        'locationSubscribed': true,
      });

      context.read<AuthBloc>().add(
        LoggedIn(user.uid, user.email!, locationSubscribed: true),
      );
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Payment successful! ✅')),
    );

    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const HomeScreen()),
      (route) => false,
    );
  } catch (e) {
    debugPrint('❌ Stripe payment error: $e');
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Payment failed. Please try again.')),
    );
  }
}

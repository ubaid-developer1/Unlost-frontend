import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:permission_handler/permission_handler.dart';
import 'package:unstop/main.dart';

Future<void> scheduleNotification({
  required String itemId, // 🆕 Pass itemId
  required String title,
  required String body,
  required TimeOfDay time,
  required String frequency,
}) async {
  final now = DateTime.now();
  final scheduledDate = DateTime(
    now.year,
    now.month,
    now.day,
    time.hour,
    time.minute,
  );

  AndroidScheduleMode androidScheduleMode = AndroidScheduleMode.inexact;

  if (Platform.isAndroid) {
    final androidFlutterLocalNotificationsPlugin =
        flutterLocalNotificationsPlugin.resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();

    final granted = await androidFlutterLocalNotificationsPlugin?.requestExactAlarmsPermission();
    if (granted != null && granted) {
      androidScheduleMode = AndroidScheduleMode.exact;
    } else {
      debugPrint('⚠️ Exact alarms permission not granted. Using inexact.');
    }
  }

  final scheduleTime = _getNextScheduledDate(scheduledDate, frequency);

  debugPrint('⏰ Scheduling notification for: ${scheduleTime.toString()}');

  await flutterLocalNotificationsPlugin.zonedSchedule(
    itemId.hashCode, // 🆕 Use itemId.hashCode as notification id
    title,
    body,
    scheduleTime,
    const NotificationDetails(
      android: AndroidNotificationDetails(
        'your_channel_id',
        'your_channel_name',
        channelDescription: 'Your channel description',
        importance: Importance.max,
        priority: Priority.high,
      ),
      iOS: DarwinNotificationDetails(),
    ),
    androidScheduleMode: androidScheduleMode,
    payload: itemId,
    matchDateTimeComponents: _getMatchComponents(frequency),
  );
}

// 🆕 Cancel old notification before updating
Future<void> cancelNotification(String itemId) async {
  await flutterLocalNotificationsPlugin.cancel(itemId.hashCode);
}

tz.TZDateTime _getNextScheduledDate(DateTime dateTime, String frequency) {
  final now = tz.TZDateTime.now(tz.local);
  final scheduled = tz.TZDateTime.from(dateTime, tz.local);

  if (scheduled.isBefore(now.add(const Duration(seconds: 30)))) {
    switch (frequency) {
      case 'Daily':
        return scheduled.add(const Duration(days: 1));
      case 'Weekly':
        return scheduled.add(const Duration(days: 7));
      case 'Monthly':
        return tz.TZDateTime(
          tz.local,
          scheduled.year,
          scheduled.month + 1,
          scheduled.day,
          scheduled.hour,
          scheduled.minute,
        );
      default:
        return scheduled;
    }
  }
  return scheduled;
}

DateTimeComponents? _getMatchComponents(String frequency) {
  switch (frequency) {
    case 'Daily':
      return DateTimeComponents.time;
    case 'Weekly':
      return DateTimeComponents.dayOfWeekAndTime;
    case 'Monthly':
      return DateTimeComponents.dayOfMonthAndTime;
    default:
      return null;
  }
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:unstop/core/color_constants.dart';
import 'package:unstop/notification/schedule_noti.dart';
import 'package:unstop/screens/homescreen.dart';
import 'package:unstop/widgets/customButton.dart';
import 'package:unstop/widgets/lent_borrow_button.dart';
import 'package:unstop/main.dart';

class EditItemScreen extends StatefulWidget {
  const EditItemScreen({super.key});

  @override
  State<EditItemScreen> createState() => _EditItemScreenState();
}

class _EditItemScreenState extends State<EditItemScreen> {
  final _auth = FirebaseAuth.instance;
  final _firestore = FirebaseFirestore.instance;

  final TextEditingController searchController = TextEditingController();
  final TextEditingController itemNameController = TextEditingController();
  final TextEditingController locationDetailsController =
      TextEditingController();
  final TextEditingController personNameController = TextEditingController();

  List<Map<String, dynamic>> allItems = [];
  List<Map<String, dynamic>> filteredItems = [];

  String? selectedItemId;
  String? selectedLocation;
  String? borrowType;
  String? reminderFrequency;
  TimeOfDay? reminderTime;
  List<String> firebaseLocations = [];

  @override
  void initState() {
    super.initState();
    fetchAllItems();
    fetchLocations();
  }

  Future<void> fetchAllItems() async {
    final user = _auth.currentUser;
    if (user == null) return;

    final snapshot =
        await _firestore
            .collection('users')
            .doc(user.uid)
            .collection('items')
            .get();

    setState(() {
      allItems =
          snapshot.docs.map((doc) {
            final data = doc.data();
            return {'id': doc.id, ...data};
          }).toList();
    });
  }

  Future<void> fetchLocations() async {
    final user = _auth.currentUser;
    if (user == null) return;

    final snapshot =
        await _firestore
            .collection('users')
            .doc(user.uid)
            .collection('locations')
            .get();

    setState(() {
      firebaseLocations =
          snapshot.docs.map((doc) => doc['name'].toString()).toList();
    });
  }

  void onItemSelected(Map<String, dynamic> item) {
    selectedItemId = item['id'];
    itemNameController.text = item['name'] ?? '';
    locationDetailsController.text = item['locationDetails'] ?? '';
    selectedLocation = item['location'];

    // Only show borrow section if borrowType is non-empty and person or reminder is present
    final borrow = item['borrowType'];
    final person = item['person'];
    final frequency = item['reminderFrequency'];
    final time = item['reminderTime'];

    if (borrow != null &&
        borrow.toString().trim().isNotEmpty &&
        (person != null && person.toString().trim().isNotEmpty ||
            frequency != null && frequency.toString().trim().isNotEmpty ||
            time != null && time.toString().trim().isNotEmpty)) {
      borrowType = borrow;
      personNameController.text = person ?? '';
      reminderFrequency = frequency;
      if (time is String && time.contains(':')) {
        final parts = time.split(":");
        reminderTime = TimeOfDay(
          hour: int.tryParse(parts[0]) ?? 0,
          minute: int.tryParse(parts[1].split(' ')[0]) ?? 0,
        );
      }
    } else {
      borrowType = null;
      personNameController.clear();
      reminderFrequency = null;
      reminderTime = null;
    }

    // Clear dropdown and input
    setState(() {
      searchController.clear();
      filteredItems = [];
    });

    FocusScope.of(context).unfocus();
  }

  //  void onItemSelected(Map<String, dynamic> item) {
  //   selectedItemId = item['id'];
  //   itemNameController.text = item['name'] ?? '';
  //   locationDetailsController.text = item['locationDetails'] ?? '';
  //   personNameController.text = item['person'] ?? '';
  //   selectedLocation = item['location'];
  //   borrowType = item['borrowType'];
  //   reminderFrequency = item['reminderFrequency'];

  //   final timeString = item['reminderTime'];
  //   if (timeString != null && timeString is String && timeString.contains(':')) {
  //     final parts = timeString.split(":");
  //     reminderTime = TimeOfDay(
  //       hour: int.tryParse(parts[0]) ?? 0,
  //       minute: int.tryParse(parts[1].split(' ')[0]) ?? 0,
  //     );
  //   }

  //   // 👇 Close the dropdown
  //   setState(() {
  //     searchController.clear();        // clear the input
  //     filteredItems = [];              // clear the dropdown list
  //   });

  //   FocusScope.of(context).unfocus();  // dismiss the keyboard
  // }

  void clearBorrowType() {
    setState(() {
      borrowType = null;
      personNameController.clear();
      reminderFrequency = null;
      reminderTime = null;
    });
  }

  Future<void> updateItem() async {
    if (selectedItemId == null) return;

    final user = _auth.currentUser;
    final name = itemNameController.text.trim();
    final details = locationDetailsController.text.trim();
    final person = personNameController.text.trim();

    if (user == null || name.isEmpty || selectedLocation == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill all required fields')),
      );
      return;
    }
    // ✅ Validate borrowType dependencies
    if (borrowType != null && borrowType!.isNotEmpty) {
      final person = personNameController.text.trim();
      final freq = reminderFrequency;
      final time = reminderTime;

      if (person.isEmpty || freq == null || time == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Please fill all Lent/Borrowed details or unselect it',
            ),
          ),
        );
        return;
      }
    }

    await _firestore
        .collection('users')
        .doc(user.uid)
        .collection('items')
        .doc(selectedItemId)
        .update({
          'name': name,
          'location': selectedLocation,
          'locationDetails': details,
          'borrowType': borrowType ?? '',
          'person': borrowType == null ? null : person,
          'reminderFrequency': borrowType == null ? null : reminderFrequency,
          'reminderTime':
              borrowType == null ? null : reminderTime?.format(context),
          'updatedAt': FieldValue.serverTimestamp(),
        });

    await flutterLocalNotificationsPlugin.cancel(selectedItemId.hashCode);

    if (borrowType != null && borrowType!.isNotEmpty) {
      String notificationBody =
          borrowType == 'Lent'
              ? '$name was Lent to $person'
              // 'Reminder: $person has the item ($name)'
              : '$name was borrowed from $person';
      // 'You borrowed the item ($name)';

      await scheduleNotification(
        itemId: selectedItemId!,
        title: 'Item Reminder 📦',
        body: notificationBody,
        time: reminderTime!,
        frequency: reminderFrequency!,
      );
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Item updated successfully! ✅')),
    );
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (context) => HomeScreen()),
      (Route<dynamic> route) => false,
    );
  }

  Future<void> deleteItem() async {
    if (selectedItemId == null) return;

    final user = _auth.currentUser;
    if (user == null) return;

    await flutterLocalNotificationsPlugin.cancel(selectedItemId.hashCode);
    await _firestore
        .collection('users')
        .doc(user.uid)
        .collection('items')
        .doc(selectedItemId)
        .delete();

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Item deleted successfully! 🗑️')),
    );
    setState(() {
      selectedItemId = null;
      itemNameController.clear();
      locationDetailsController.clear();
      personNameController.clear();
      selectedLocation = null;
      borrowType = null;
      reminderFrequency = null;
      reminderTime = null;
    });
  }

  Widget buildTextField(
    TextEditingController controller,
    String hint, {
    int maxLines = 1,
  }) {
    return TextField(
      controller: controller,
      style: const TextStyle(color: Colors.black),
      maxLines: maxLines,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.grey),
        border: const OutlineInputBorder(),
        enabledBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Colors.grey),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.grey[850],
        title: const Text(
          'Edit Item',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 24,
          ),
        ),
        leading: const BackButton(color: Colors.white),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            InkWell(
              onTap: () {},
              child: Container(
                height: 55,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: ColorConstants.blue,
                ),
                child: const Center(
                  child: Text(
                    'EDIT ITEM',
                    style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: 20),
            buildTitle('SELECT ITEM'),
            const SizedBox(height: 8),
            TextField(
              controller: searchController,
              onChanged: (value) {
                setState(() {
                  filteredItems =
                      allItems
                          .where(
                            (item) => item['name']
                                .toString()
                                .toLowerCase()
                                .contains(value.toLowerCase()),
                          )
                          .toList();
                });
              },
              decoration: InputDecoration(
                hintText: 'Choose an item',
                suffixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey),
                ),
                // focusedBorder: OutlineInputBorder(
                //   borderSide: BorderSide(color: Colors.grey),
                // ),
              ),
            ),
            if (searchController.text.isNotEmpty && filteredItems.isNotEmpty)
              const Padding(
                padding: EdgeInsets.only(top: 12),
                // child: Center(child: CircularProgressIndicator()),
              ),
            if (searchController.text.isNotEmpty && filteredItems.isNotEmpty)
              ...filteredItems
                  .take(5)
                  .map(
                    (item) => Column(
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.4),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: ListTile(
                            title: Text(
                              item['name'] ?? '',
                              style: TextStyle(color: Colors.white),
                            ),
                            // subtitle: Text(item['location'] ?? ''),
                            onTap: () => onItemSelected(item),
                          ),
                        ),
                        SizedBox(height: 5),
                      ],
                    ),
                  ),
            const SizedBox(height: 16),
            buildTitle('RENAME ITEM'),
            const SizedBox(height: 8),
            buildTextField(itemNameController, 'Item Name'),
            const SizedBox(height: 12),
            buildTitle('EDIT LOCATION DETAILS'),
            const SizedBox(height: 8),
            buildTextField(locationDetailsController, 'Location Details'),
            const SizedBox(height: 12),
            buildTitle('MOVE TO ANOTHER LOCATION'),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: selectedLocation,
              isExpanded: true,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Select Location',
                contentPadding: EdgeInsets.symmetric(
                  vertical: 16,
                  horizontal: 12,
                ),
              ),
              items:
                  firebaseLocations
                      .map(
                        (loc) => DropdownMenuItem(
                          value: loc,
                          child: Text(
                            loc,
                            style: TextStyle(
                              height: 0.1,
                              fontSize: 15,
                            ), // helps with vertical alignment
                          ),
                        ),
                      )
                      .toList(),
              onChanged: (value) => setState(() => selectedLocation = value),
            ),

            const SizedBox(height: 12),
            buildTitle('ITEM BORROWED OR LENT'),
            const SizedBox(height: 8),
            Row(
              children:
                  ['Lent', 'Borrowed'].map((type) {
                    final isSelected = borrowType == type;
                    return Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: customButtonLentBorrow(
                          label: type,
                          color: isSelected ? Colors.blue : Colors.grey,
                          onPressed: () {
                            setState(() {
                              borrowType = isSelected ? null : type;
                            });
                          },
                        ),
                      ),
                    );
                  }).toList(),
            ),
            SizedBox(height: 20),
            if (borrowType != null) ...[
              TextField(
                controller: personNameController,
                style: const TextStyle(color: Colors.black),
                decoration: const InputDecoration(
                  hintText: 'Type name of person',
                  hintStyle: TextStyle(color: Colors.grey),
                  border: OutlineInputBorder(),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.black),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'SET A REMINDER',
                style: TextStyle(color: Colors.blueAccent),
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: reminderFrequency,

                dropdownColor: Colors.white,
                iconEnabledColor: Colors.black,
                hint: const Text(
                  'Select Frequency',
                  style: TextStyle(color: Colors.black),
                ),
                style: const TextStyle(color: Colors.black),
                items:
                    ['Daily', 'Weekly', 'Monthly']
                        .map(
                          (freq) =>
                              DropdownMenuItem(value: freq, child: Text(freq)),
                        )
                        .toList(),
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'Reminder Frequency',
                ),
                onChanged: (value) => setState(() => reminderFrequency = value),
              ),
              const SizedBox(height: 12),
              InkWell(
                onTap: () async {
                  final picked = await showTimePicker(
                    context: context,
                    initialTime: TimeOfDay.now(),
                  );
                  if (picked != null) {
                    setState(() => reminderTime = picked);
                  }
                },
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    reminderTime != null
                        ? reminderTime!.format(context)
                        : 'Select Reminder Time',
                    style: const TextStyle(color: Colors.black),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              // buildTextField(personNameController, 'Name of person'),
              // const SizedBox(height: 12),
              // DropdownButtonFormField<String>(
              // value: reminderFrequency,
              // items:
              //     ['Daily', 'Weekly', 'Monthly']
              //         .map(
              //           (freq) =>
              //               DropdownMenuItem(value: freq, child: Text(freq)),
              //         )
              //         .toList(),
              // onChanged: (val) => setState(() => reminderFrequency = val),
              // decoration: const InputDecoration(
              //   border: OutlineInputBorder(),
              //   hintText: 'Reminder Frequency',
              // ),
              // ),
              // const SizedBox(height: 12),
              // InkWell(
              //   onTap: () async {
              //     final picked = await showTimePicker(
              //       context: context,
              //       initialTime: TimeOfDay.now(),
              //     );
              //     if (picked != null) setState(() => reminderTime = picked);
              //   },
              //   child: Container(
              //     padding: const EdgeInsets.all(12),
              //     decoration: BoxDecoration(
              //       border: Border.all(color: Colors.grey),
              //       borderRadius: BorderRadius.circular(6),
              //     ),
              //     child: Text(reminderTime?.format(context) ?? 'Select Time'),
              //   ),
              // ),
            ],
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: customButton(
                    label: 'Update',
                    color: Colors.green,
                    icon: Icons.update,
                    onPressed: updateItem,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: customButton(
                    label: 'Delete',
                    color: Colors.red,
                    icon: Icons.delete,
                    onPressed: deleteItem,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 35),
          ],
        ),
      ),
    );
  }

  Widget buildTitle(String text) {
    return Text(
      text,
      style: const TextStyle(
        color: Colors.blueAccent,
        fontSize: 16,
        fontWeight: FontWeight.bold,
      ),
    );
  }
}
